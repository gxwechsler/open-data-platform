"""
Visualization module for Open Data Platform.
"""
