"""
Open Data Platform

A comprehensive data platform for retrieving, storing, and analyzing
World Bank, IMF, and additional open data sources for economic analysis.
"""

__version__ = "0.1.0"
