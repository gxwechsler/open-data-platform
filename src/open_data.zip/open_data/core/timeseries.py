"""
Time Series Analysis Module.

Provides time series analysis capabilities:
- Trend detection and decomposition
- Moving averages and smoothing
- Growth rate calculations
- Forecasting (linear, exponential, Holt-Winters)
- Change point detection
"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Literal

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize

from open_data.core.query import DataQuery, QueryBuilder


class TrendType(str, Enum):
    """Types of trends detected."""
    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"
    VOLATILE = "volatile"


class ForecastMethod(str, Enum):
    """Available forecasting methods."""
    LINEAR = "linear"
    EXPONENTIAL = "exponential"
    HOLT = "holt"  # Holt's linear trend
    MOVING_AVERAGE = "moving_average"


@dataclass
class TrendAnalysis:
    """Result of trend analysis."""
    trend_type: TrendType
    slope: float
    r_squared: float
    p_value: float
    avg_growth_rate: float
    volatility: float
    start_value: float
    end_value: float
    total_change_pct: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "trend_type": self.trend_type.value,
            "slope": self.slope,
            "r_squared": self.r_squared,
            "p_value": self.p_value,
            "avg_growth_rate": self.avg_growth_rate,
            "volatility": self.volatility,
            "start_value": self.start_value,
            "end_value": self.end_value,
            "total_change_pct": self.total_change_pct,
        }


@dataclass
class ForecastResult:
    """Result of a forecast."""
    method: ForecastMethod
    forecast_values: list[float]
    forecast_years: list[int]
    confidence_lower: list[float]
    confidence_upper: list[float]
    mape: float | None  # Mean Absolute Percentage Error
    rmse: float | None  # Root Mean Square Error

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame({
            "year": self.forecast_years,
            "forecast": self.forecast_values,
            "lower_95": self.confidence_lower,
            "upper_95": self.confidence_upper,
        })

    def to_dict(self) -> dict[str, Any]:
        return {
            "method": self.method.value,
            "forecast": dict(zip(self.forecast_years, self.forecast_values)),
            "mape": self.mape,
            "rmse": self.rmse,
        }


class TimeSeriesAnalyzer:
    """
    Analyze time series data for trends, patterns, and forecasts.
    """

    def __init__(self, data: pd.DataFrame | None = None):
        """
        Initialize analyzer.

        Args:
            data: DataFrame with 'year' and 'value' columns.
        """
        self.data = data
        self._validate_data()

    def _validate_data(self) -> None:
        """Validate input data."""
        if self.data is not None:
            if "year" not in self.data.columns or "value" not in self.data.columns:
                raise ValueError("Data must have 'year' and 'value' columns")
            self.data = self.data.sort_values("year").reset_index(drop=True)
            self.data["value"] = pd.to_numeric(self.data["value"], errors="coerce")

    def load_indicator(
        self,
        indicator: str,
        country: str,
        start_year: int = 1960,
        end_year: int | None = None,
    ) -> "TimeSeriesAnalyzer":
        """
        Load data for an indicator and country.

        Args:
            indicator: Indicator code.
            country: Country ISO3 code.
            start_year: Start year.
            end_year: End year.

        Returns:
            Self for chaining.
        """
        df = DataQuery.get_time_series(indicator, country, start_year, end_year)
        self.data = df[["year", "value"]].dropna()
        self._validate_data()
        return self

    def analyze_trend(self) -> TrendAnalysis:
        """
        Analyze the trend in the time series.

        Returns:
            TrendAnalysis with trend characteristics.
        """
        if self.data is None or len(self.data) < 3:
            raise ValueError("Need at least 3 data points for trend analysis")

        years = self.data["year"].values
        values = self.data["value"].values

        # Remove NaN values
        mask = ~np.isnan(values)
        years = years[mask]
        values = values[mask]

        if len(values) < 3:
            raise ValueError("Need at least 3 non-null data points")

        # Linear regression
        slope, intercept, r_value, p_value, std_err = stats.linregress(years, values)
        r_squared = r_value ** 2

        # Calculate growth rates
        # For data that's already a growth rate (like GDP growth %), just average it
        # For absolute values (like GDP amount), calculate year-over-year changes
        if abs(np.nanmean(values)) < 100:  # Likely already a percentage/rate
            avg_growth_rate = np.nanmean(values)
            growth_rates = values  # Already growth rates
        else:  # Absolute values
            growth_rates = np.diff(values) / values[:-1] * 100
            avg_growth_rate = np.nanmean(growth_rates)
        volatility = np.nanstd(growth_rates)

        # Total change
        start_value = values[0]
        end_value = values[-1]
        total_change_pct = (end_value - start_value) / start_value * 100 if start_value != 0 else 0

        # Determine trend type
        if p_value > 0.1:
            trend_type = TrendType.VOLATILE if volatility > 10 else TrendType.STABLE
        elif slope > 0:
            trend_type = TrendType.INCREASING
        else:
            trend_type = TrendType.DECREASING

        return TrendAnalysis(
            trend_type=trend_type,
            slope=slope,
            r_squared=r_squared,
            p_value=p_value,
            avg_growth_rate=avg_growth_rate,
            volatility=volatility,
            start_value=start_value,
            end_value=end_value,
            total_change_pct=total_change_pct,
        )

    def moving_average(self, window: int = 3) -> pd.DataFrame:
        """
        Calculate moving average.

        Args:
            window: Window size for moving average.

        Returns:
            DataFrame with original and smoothed values.
        """
        if self.data is None:
            raise ValueError("No data loaded")

        result = self.data.copy()
        result["ma"] = result["value"].rolling(window=window, center=True).mean()
        result["ma_forward"] = result["value"].rolling(window=window).mean()
        return result

    def growth_rates(self, periods: int = 1) -> pd.DataFrame:
        """
        Calculate growth rates.

        Args:
            periods: Number of periods for growth calculation.

        Returns:
            DataFrame with growth rates.
        """
        if self.data is None:
            raise ValueError("No data loaded")

        result = self.data.copy()
        result["growth_rate"] = result["value"].pct_change(periods=periods) * 100
        result["log_growth"] = np.log(result["value"]).diff(periods=periods) * 100
        return result

    def cagr(self, start_year: int | None = None, end_year: int | None = None) -> float:
        """
        Calculate Compound Annual Growth Rate.

        Args:
            start_year: Start year (default: first year in data).
            end_year: End year (default: last year in data).

        Returns:
            CAGR as percentage.
        """
        if self.data is None or len(self.data) < 2:
            raise ValueError("Need at least 2 data points")

        df = self.data.copy()

        if start_year:
            df = df[df["year"] >= start_year]
        if end_year:
            df = df[df["year"] <= end_year]

        if len(df) < 2:
            raise ValueError("Not enough data points in range")

        start_val = df.iloc[0]["value"]
        end_val = df.iloc[-1]["value"]
        n_years = df.iloc[-1]["year"] - df.iloc[0]["year"]

        if start_val <= 0 or end_val <= 0 or n_years <= 0:
            return 0.0

        return ((end_val / start_val) ** (1 / n_years) - 1) * 100

    def forecast(
        self,
        periods: int = 5,
        method: ForecastMethod = ForecastMethod.HOLT,
        confidence: float = 0.95,
    ) -> ForecastResult:
        """
        Generate forecasts.

        Args:
            periods: Number of periods to forecast.
            method: Forecasting method to use.
            confidence: Confidence level for intervals.

        Returns:
            ForecastResult with predictions.
        """
        if self.data is None or len(self.data) < 3:
            raise ValueError("Need at least 3 data points for forecasting")

        years = self.data["year"].values
        values = self.data["value"].values

        # Remove NaN
        mask = ~np.isnan(values)
        years = years[mask]
        values = values[mask]

        last_year = int(years[-1])
        forecast_years = list(range(last_year + 1, last_year + periods + 1))

        if method == ForecastMethod.LINEAR:
            return self._forecast_linear(years, values, forecast_years, confidence)
        elif method == ForecastMethod.EXPONENTIAL:
            return self._forecast_exponential(years, values, forecast_years, confidence)
        elif method == ForecastMethod.HOLT:
            return self._forecast_holt(years, values, forecast_years, confidence)
        elif method == ForecastMethod.MOVING_AVERAGE:
            return self._forecast_ma(years, values, forecast_years, confidence)
        else:
            raise ValueError(f"Unknown method: {method}")

    def _forecast_linear(
        self,
        years: np.ndarray,
        values: np.ndarray,
        forecast_years: list[int],
        confidence: float,
    ) -> ForecastResult:
        """Linear trend forecast."""
        slope, intercept, r_value, p_value, std_err = stats.linregress(years, values)

        # Forecast
        forecast_values = [slope * y + intercept for y in forecast_years]

        # Confidence intervals
        n = len(years)
        mean_x = np.mean(years)
        ss_x = np.sum((years - mean_x) ** 2)
        residuals = values - (slope * years + intercept)
        mse = np.sum(residuals ** 2) / (n - 2)

        z = stats.norm.ppf((1 + confidence) / 2)

        confidence_lower = []
        confidence_upper = []
        for i, y in enumerate(forecast_years):
            se = np.sqrt(mse * (1 + 1/n + (y - mean_x)**2 / ss_x))
            confidence_lower.append(forecast_values[i] - z * se)
            confidence_upper.append(forecast_values[i] + z * se)

        # Calculate errors
        fitted = slope * years + intercept
        mape = np.mean(np.abs((values - fitted) / values)) * 100
        rmse = np.sqrt(np.mean((values - fitted) ** 2))

        return ForecastResult(
            method=ForecastMethod.LINEAR,
            forecast_values=forecast_values,
            forecast_years=forecast_years,
            confidence_lower=confidence_lower,
            confidence_upper=confidence_upper,
            mape=mape,
            rmse=rmse,
        )

    def _forecast_exponential(
        self,
        years: np.ndarray,
        values: np.ndarray,
        forecast_years: list[int],
        confidence: float,
    ) -> ForecastResult:
        """Exponential trend forecast."""
        # Use log-linear regression for exponential trend
        log_values = np.log(np.maximum(values, 1e-10))
        slope, intercept, _, _, _ = stats.linregress(years, log_values)

        # Forecast
        forecast_values = [np.exp(slope * y + intercept) for y in forecast_years]

        # Simple confidence intervals based on historical volatility
        residuals = values - np.exp(slope * years + intercept)
        std_residual = np.std(residuals)
        z = stats.norm.ppf((1 + confidence) / 2)

        confidence_lower = [max(0, f - z * std_residual * (1 + 0.1 * i)) for i, f in enumerate(forecast_values)]
        confidence_upper = [f + z * std_residual * (1 + 0.1 * i) for i, f in enumerate(forecast_values)]

        # Calculate errors
        fitted = np.exp(slope * years + intercept)
        mape = np.mean(np.abs((values - fitted) / values)) * 100
        rmse = np.sqrt(np.mean((values - fitted) ** 2))

        return ForecastResult(
            method=ForecastMethod.EXPONENTIAL,
            forecast_values=forecast_values,
            forecast_years=forecast_years,
            confidence_lower=confidence_lower,
            confidence_upper=confidence_upper,
            mape=mape,
            rmse=rmse,
        )

    def _forecast_holt(
        self,
        years: np.ndarray,
        values: np.ndarray,
        forecast_years: list[int],
        confidence: float,
    ) -> ForecastResult:
        """Holt's linear exponential smoothing forecast."""
        n = len(values)

        # Optimize alpha and beta
        def holt_loss(params):
            alpha, beta = params
            level = values[0]
            trend = values[1] - values[0] if n > 1 else 0

            sse = 0
            for t in range(1, n):
                forecast = level + trend
                error = values[t] - forecast
                sse += error ** 2

                level_new = alpha * values[t] + (1 - alpha) * (level + trend)
                trend = beta * (level_new - level) + (1 - beta) * trend
                level = level_new

            return sse

        # Find optimal parameters
        result = minimize(
            holt_loss,
            x0=[0.3, 0.1],
            bounds=[(0.01, 0.99), (0.01, 0.99)],
            method="L-BFGS-B",
        )
        alpha, beta = result.x

        # Apply Holt's method with optimal parameters
        level = values[0]
        trend = values[1] - values[0] if n > 1 else 0

        fitted = [level]
        for t in range(1, n):
            level_new = alpha * values[t] + (1 - alpha) * (level + trend)
            trend = beta * (level_new - level) + (1 - beta) * trend
            level = level_new
            fitted.append(level + trend)

        # Forecast
        forecast_values = []
        for h in range(1, len(forecast_years) + 1):
            forecast_values.append(level + h * trend)

        # Confidence intervals
        residuals = values - np.array(fitted)
        std_residual = np.std(residuals)
        z = stats.norm.ppf((1 + confidence) / 2)

        confidence_lower = [f - z * std_residual * np.sqrt(h) for h, f in enumerate(forecast_values, 1)]
        confidence_upper = [f + z * std_residual * np.sqrt(h) for h, f in enumerate(forecast_values, 1)]

        # Calculate errors
        mape = np.mean(np.abs((values - np.array(fitted)) / values)) * 100
        rmse = np.sqrt(np.mean((values - np.array(fitted)) ** 2))

        return ForecastResult(
            method=ForecastMethod.HOLT,
            forecast_values=forecast_values,
            forecast_years=forecast_years,
            confidence_lower=confidence_lower,
            confidence_upper=confidence_upper,
            mape=mape,
            rmse=rmse,
        )

    def _forecast_ma(
        self,
        years: np.ndarray,
        values: np.ndarray,
        forecast_years: list[int],
        confidence: float,
    ) -> ForecastResult:
        """Moving average forecast."""
        window = min(5, len(values) // 2)
        ma = np.convolve(values, np.ones(window) / window, mode="valid")

        # Use last MA value and trend for forecast
        last_ma = ma[-1]
        if len(ma) > 1:
            trend = (ma[-1] - ma[0]) / len(ma)
        else:
            trend = 0

        forecast_values = [last_ma + trend * (i + 1) for i in range(len(forecast_years))]

        # Confidence intervals
        std_residual = np.std(values[-window:])
        z = stats.norm.ppf((1 + confidence) / 2)

        confidence_lower = [f - z * std_residual * np.sqrt(i + 1) for i, f in enumerate(forecast_values)]
        confidence_upper = [f + z * std_residual * np.sqrt(i + 1) for i, f in enumerate(forecast_values)]

        return ForecastResult(
            method=ForecastMethod.MOVING_AVERAGE,
            forecast_values=forecast_values,
            forecast_years=forecast_years,
            confidence_lower=confidence_lower,
            confidence_upper=confidence_upper,
            mape=None,
            rmse=None,
        )

    def detect_change_points(self, min_segment: int = 5) -> list[int]:
        """
        Detect structural change points in the series.

        Args:
            min_segment: Minimum segment length.

        Returns:
            List of years where change points occur.
        """
        if self.data is None or len(self.data) < min_segment * 2:
            return []

        values = self.data["value"].dropna().values
        years = self.data["year"].values

        n = len(values)
        change_points = []

        # Simple approach: look for significant changes in mean
        for i in range(min_segment, n - min_segment):
            left_mean = np.mean(values[:i])
            right_mean = np.mean(values[i:])
            left_std = np.std(values[:i])
            right_std = np.std(values[i:])

            # T-test for difference in means
            pooled_std = np.sqrt((left_std**2 / i + right_std**2 / (n - i)))
            if pooled_std > 0:
                t_stat = abs(left_mean - right_mean) / pooled_std
                if t_stat > 2.5:  # Significant change
                    change_points.append(int(years[i]))

        # Remove nearby points (keep most significant)
        if change_points:
            filtered = [change_points[0]]
            for cp in change_points[1:]:
                if cp - filtered[-1] >= min_segment:
                    filtered.append(cp)
            return filtered

        return change_points


def analyze_indicator_trend(
    indicator: str,
    country: str,
    start_year: int = 1990,
    end_year: int | None = None,
) -> TrendAnalysis:
    """
    Analyze trend for an indicator and country.

    Args:
        indicator: Indicator code.
        country: Country ISO3 code.
        start_year: Start year.
        end_year: End year.

    Returns:
        TrendAnalysis result.
    """
    analyzer = TimeSeriesAnalyzer()
    analyzer.load_indicator(indicator, country, start_year, end_year)
    return analyzer.analyze_trend()


def forecast_indicator(
    indicator: str,
    country: str,
    periods: int = 5,
    method: str = "holt",
    start_year: int = 1990,
) -> ForecastResult:
    """
    Forecast an indicator for a country.

    Args:
        indicator: Indicator code.
        country: Country ISO3 code.
        periods: Number of periods to forecast.
        method: Forecasting method.
        start_year: Start year for historical data.

    Returns:
        ForecastResult with predictions.
    """
    analyzer = TimeSeriesAnalyzer()
    analyzer.load_indicator(indicator, country, start_year)

    forecast_method = ForecastMethod(method.lower())
    return analyzer.forecast(periods, forecast_method)


def compare_trends(
    indicator: str,
    countries: list[str],
    start_year: int = 2000,
    end_year: int | None = None,
) -> pd.DataFrame:
    """
    Compare trends across multiple countries.

    Args:
        indicator: Indicator code.
        countries: List of country codes.
        start_year: Start year.
        end_year: End year.

    Returns:
        DataFrame with trend analysis for each country.
    """
    results = []

    for country in countries:
        try:
            trend = analyze_indicator_trend(indicator, country, start_year, end_year)
            results.append({
                "country": country,
                "trend_type": trend.trend_type.value,
                "avg_growth_rate": trend.avg_growth_rate,
                "volatility": trend.volatility,
                "total_change_pct": trend.total_change_pct,
                "r_squared": trend.r_squared,
            })
        except Exception:
            continue

    return pd.DataFrame(results)
