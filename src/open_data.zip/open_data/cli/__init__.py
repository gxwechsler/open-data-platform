"""
CLI package for Open Data Platform.
"""

from open_data.cli.main import app

__all__ = ["app"]
